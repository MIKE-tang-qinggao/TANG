package com.example.orderfoodapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "OrderFood.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_USERS = "Users";
    public static final String TABLE_MENU = "Menu";
    public static final String TABLE_ORDERS = "Orders";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_USERS = "CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "email TEXT UNIQUE, " +
                "password TEXT, " +
                "role TEXT)";
        db.execSQL(CREATE_USERS);

        String CREATE_MENU = "CREATE TABLE " + TABLE_MENU + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, " +
                "price REAL, " +
                "description TEXT)";
        db.execSQL(CREATE_MENU);

        String CREATE_ORDERS = "CREATE TABLE " + TABLE_ORDERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "userEmail TEXT, " +
                "menuName TEXT, " +
                "price REAL, " +
                "orderTime TEXT)";
        db.execSQL(CREATE_ORDERS);

        db.execSQL("INSERT INTO " + TABLE_MENU + " (name, price, description) VALUES " +
                "('Burger', 8.0, 'Beef burger with cheese')," +
                "('Pizza', 12.0, 'Cheesy pizza with toppings')," +
                "('Salad', 6.0, 'Fresh garden salad')," +
                "('Noodles', 7.0, 'Spicy chicken noodles')," +
                "('Sushi', 10.0, 'Fresh salmon sushi')");
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS +
                " WHERE email=? AND password=?", new String[]{email, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // 获取用户角色（user/admin）
    public String getUserRole(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT role FROM " + TABLE_USERS +
                " WHERE email=? AND password=?", new String[]{email, password});
        String role = null;
        if (cursor.moveToFirst()) {
            role = cursor.getString(0);
        }
        cursor.close();
        return role;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MENU);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORDERS); // ✅ 确保删除旧订单表
        onCreate(db);
    }
}
