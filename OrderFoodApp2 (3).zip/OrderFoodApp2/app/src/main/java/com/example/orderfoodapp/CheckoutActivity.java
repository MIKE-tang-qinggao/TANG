package com.example.orderfoodapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class CheckoutActivity extends AppCompatActivity {

    TextView tvTotal;
    ListView listViewCheckout;
    Button btnCheckout, btnBackToMenu;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        tvTotal = findViewById(R.id.tvTotal);
        listViewCheckout = findViewById(R.id.listViewCheckout);
        btnCheckout = findViewById(R.id.btnCheckout);
        btnBackToMenu = findViewById(R.id.btnBackToMenu);

        dbHelper = new DatabaseHelper(this);
        ArrayList<MenuItem> cartList = UserHomeActivity.cartList;

        double total = 0;
        for (MenuItem item : cartList) {
            total += item.getPrice() * item.getQuantity();
        }
        tvTotal.setText("Total: RM" + String.format("%.2f", total));

        CartAdapter adapter = new CartAdapter(this, cartList);
        listViewCheckout.setAdapter(adapter);

        btnCheckout.setOnClickListener(v -> {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String currentDateTime = sdf.format(new Date());

            SQLiteDatabase db = dbHelper.getWritableDatabase();

            for (MenuItem item : cartList) {
                ContentValues values = new ContentValues();
                values.put("userEmail", "user@example.com"); // 实际应获取当前登录用户邮箱
                values.put("menuName", item.getName());
                values.put("price", item.getPrice() * item.getQuantity());
                values.put("orderTime", currentDateTime);

                long result = db.insert(DatabaseHelper.TABLE_ORDERS, null, values);
                if (result == -1) {
                    Toast.makeText(this, "Failed to place order", Toast.LENGTH_SHORT).show();
                }
            }

            Toast.makeText(this, "Order placed successfully!", Toast.LENGTH_SHORT).show();
            UserHomeActivity.cartList.clear();

            Intent intent = new Intent(CheckoutActivity.this, UserHomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });

        btnBackToMenu.setOnClickListener(v -> {
            Intent intent = new Intent(CheckoutActivity.this, UserHomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });
    }
}
