package com.example.orderfoodapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class UserHomeActivity extends AppCompatActivity {

    ListView listViewMenu;
    Button btnViewMenu, btnCart;
    DatabaseHelper dbHelper;
    ArrayList<MenuItem> menuList;
    public static ArrayList<MenuItem> cartList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home);

        listViewMenu = findViewById(R.id.listViewMenu);
        btnViewMenu = findViewById(R.id.btnViewMenu);
        btnCart = findViewById(R.id.btnCart);
        dbHelper = new DatabaseHelper(this);

        loadMenuData();

        listViewMenu.setOnItemClickListener((parent, view, position, itemId) -> {
            MenuItem selectedItem = menuList.get(position);

            Intent intent = new Intent(UserHomeActivity.this, MenuDetailActivity.class);
            intent.putExtra("id", selectedItem.getId());
            intent.putExtra("name", selectedItem.getName());
            intent.putExtra("price", selectedItem.getPrice());
            intent.putExtra("description", selectedItem.getDescription());
            startActivity(intent);
        });

        btnViewMenu.setOnClickListener(v -> {
            if (!menuList.isEmpty()) {
                MenuItem firstItem = menuList.get(0);
                Intent intent = new Intent(UserHomeActivity.this, MenuDetailActivity.class);
                intent.putExtra("id", firstItem.getId());
                intent.putExtra("name", firstItem.getName());
                intent.putExtra("price", firstItem.getPrice());
                intent.putExtra("description", firstItem.getDescription());
                startActivity(intent);
            } else {
                Toast.makeText(this, "No menu items available.", Toast.LENGTH_SHORT).show();
            }
        });

        btnCart.setOnClickListener(v -> {
            Intent intent = new Intent(UserHomeActivity.this, CartActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadMenuData();
    }

    private void loadMenuData() {
        menuList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + DatabaseHelper.TABLE_MENU, null);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            double price = cursor.getDouble(2);
            String description = cursor.getString(3);

            MenuItem item = new MenuItem(id, name, price, description, 1);
            menuList.add(item);
        }
        cursor.close();

        ArrayAdapter<MenuItem> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, menuList);
        listViewMenu.setAdapter(adapter);

        Log.d("MenuItems", "Menu loaded: " + menuList.size() + " items");
        Toast.makeText(this, "Loaded " + menuList.size() + " menu items", Toast.LENGTH_SHORT).show();
    }
}
