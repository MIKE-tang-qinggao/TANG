package com.example.orderfoodapp;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    EditText etEmail, etPassword, etRole;
    Button btnRegister;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etRole = findViewById(R.id.etRole);
        btnRegister = findViewById(R.id.btnRegister);

        dbHelper = new DatabaseHelper(this);

        btnRegister.setOnClickListener(v -> {
            User user = new User(
                    etEmail.getText().toString().trim(),
                    etPassword.getText().toString().trim(),
                    etRole.getText().toString().trim()
            );

            if (user.getEmail().isEmpty() || user.getPassword().isEmpty() || user.getRole().isEmpty()) {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put("email", user.getEmail());
                values.put("password", user.getPassword());
                values.put("role", user.getRole());

                long result = db.insert(DatabaseHelper.TABLE_USERS, null, values);
                db.close();

                if (result == -1) {
                    Toast.makeText(this, "Registration failed. Email may already exist.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show();
                    finish();
                }

            } catch (Exception e) {
                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}

