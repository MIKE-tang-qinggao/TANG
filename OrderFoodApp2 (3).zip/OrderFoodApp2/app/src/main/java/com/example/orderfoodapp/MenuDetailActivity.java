package com.example.orderfoodapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MenuDetailActivity extends AppCompatActivity {

    TextView tvName, tvPrice, tvDescription, tvQuantity;
    Button btnAddToCart, btnIncrease, btnDecrease;

    int currentQuantity = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_detail);

        // 初始化控件
        tvName = findViewById(R.id.tvName);
        tvPrice = findViewById(R.id.tvPrice);
        tvDescription = findViewById(R.id.tvDescription);
        tvQuantity = findViewById(R.id.tvQuantity);
        btnIncrease = findViewById(R.id.btnIncrease);
        btnDecrease = findViewById(R.id.btnDecrease);
        btnAddToCart = findViewById(R.id.btnAddToCart);

        Intent intent = getIntent();
        if (intent != null) {
            int id = intent.getIntExtra("id", -1);
            String name = intent.getStringExtra("name");
            double price = intent.getDoubleExtra("price", 0.0);
            String description = intent.getStringExtra("description");

            tvName.setText(name);
            tvPrice.setText(String.format("RM %.2f", price));
            tvDescription.setText(description);
            tvQuantity.setText(String.valueOf(currentQuantity));

            btnIncrease.setOnClickListener(v -> {
                currentQuantity++;
                tvQuantity.setText(String.valueOf(currentQuantity));
            });

            btnDecrease.setOnClickListener(v -> {
                if (currentQuantity > 1) {
                    currentQuantity--;
                    tvQuantity.setText(String.valueOf(currentQuantity));
                }
            });

            btnAddToCart.setOnClickListener(v -> {
                UserHomeActivity.cartList.add(new MenuItem(id, name, price, description, currentQuantity));
                Toast.makeText(this, "Item added to cart!", Toast.LENGTH_SHORT).show();
                finish();
            });
        }
    }
}

