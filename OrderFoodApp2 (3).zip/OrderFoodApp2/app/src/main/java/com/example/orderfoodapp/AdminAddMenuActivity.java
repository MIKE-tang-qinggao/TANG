package com.example.orderfoodapp;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class AdminAddMenuActivity extends AppCompatActivity {

    EditText etName, etPrice, etDescription;
    Button btnAddMenu, btnBack;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_add_menu);

        etName = findViewById(R.id.etName);
        etPrice = findViewById(R.id.etPrice);
        etDescription = findViewById(R.id.etDescription);
        btnAddMenu = findViewById(R.id.btnAddMenu);
        btnBack = findViewById(R.id.btnBack);
        dbHelper = new DatabaseHelper(this);
        btnAddMenu.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String priceStr = etPrice.getText().toString().trim();
            String desc = etDescription.getText().toString().trim();
            if (name.isEmpty() || priceStr.isEmpty() || desc.isEmpty()) {
                Toast.makeText(this, "All fields required", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                double price = Double.parseDouble(priceStr);

                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put("name", name);
                values.put("price", price);
                values.put("description", desc);

                long result = db.insert(DatabaseHelper.TABLE_MENU, null, values);
                db.close();

                if (result == -1) {
                    Toast.makeText(this, "Failed to add menu", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Menu added!", Toast.LENGTH_SHORT).show();
                    etName.setText("");
                    etPrice.setText("");
                    etDescription.setText("");
                }

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid price format", Toast.LENGTH_SHORT).show();
            }
        });
        btnBack.setOnClickListener(v -> {
            finish();
        });
    }
}
