package com.example.orderfoodapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.*;
import android.widget.*;
import java.util.ArrayList;

public class CartAdapter extends BaseAdapter {
    Context context;
    ArrayList<MenuItem> cartItems;

    public CartAdapter(Context context, ArrayList<MenuItem> cartItems) {
        this.context = context;
        this.cartItems = cartItems;
    }

    @Override
    public int getCount() {
        return cartItems.size();
    }

    @Override
    public Object getItem(int position) {
        return cartItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return cartItems.get(position).getId();
    }

    @SuppressLint("ViewHolder")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_2, parent, false);
        TextView text1 = convertView.findViewById(android.R.id.text1);
        TextView text2 = convertView.findViewById(android.R.id.text2);

        MenuItem item = cartItems.get(position);
        text1.setText(item.getName() + " x " + item.getQuantity());

        double subtotal = item.getPrice() * item.getQuantity();
        text2.setText("Price: RM" + item.getPrice() + " | Subtotal: RM" + String.format("%.2f", subtotal));

        return convertView;
    }
}
