package com.example.orderfoodapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class CartActivity extends AppCompatActivity {

    ListView listViewCart;
    TextView tvTotal;
    Button btnToCheckout;
    CartAdapter cartAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        listViewCart = findViewById(R.id.listViewCart);
        tvTotal = findViewById(R.id.tvTotal);
        btnToCheckout = findViewById(R.id.btnToCheckout);
        ArrayList<MenuItem> cartList = UserHomeActivity.cartList;
        cartAdapter = new CartAdapter(this, cartList);
        listViewCart.setAdapter(cartAdapter);
        updateTotal(cartList);
        btnToCheckout.setOnClickListener(v -> {
            Intent intent = new Intent(CartActivity.this, CheckoutActivity.class);
            startActivity(intent);
        });
    }

    private void updateTotal(ArrayList<MenuItem> cart) {
        double total = 0;
        for (MenuItem item : cart) {
            total += item.getPrice();
        }
        tvTotal.setText("Total: $" + String.format("%.2f", total));
    }
}
